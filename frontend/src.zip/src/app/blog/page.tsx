import React from 'react';

const BlogPage = () => {
  return (
    <div className="flex items-center justify-center h-screen">
      <h1 className="text-4xl font-bold">Página del Blog</h1>
    </div>
  );
};

export default BlogPage;
