import React from 'react';

const NosotrosPage = () => {
  return (
    <div className="flex items-center justify-center h-screen">
      <h1 className="text-4xl font-bold">Página de Nosotros</h1>
    </div>
  );
};

export default NosotrosPage;
