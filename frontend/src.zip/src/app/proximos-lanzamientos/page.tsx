import React from 'react';

const ProximosLanzamientosPage = () => {
  return (
    <div className="flex items-center justify-center h-screen">
      <h1 className="text-4xl font-bold">Página de Próximos Lanzamientos</h1>
    </div>
  );
};

export default ProximosLanzamientosPage;
