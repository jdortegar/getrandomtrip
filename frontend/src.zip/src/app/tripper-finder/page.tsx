import React from 'react';

const TripperFinderPage = () => {
  return (
    <div className="flex items-center justify-center h-screen">
      <h1 className="text-4xl font-bold">Página de Tripper Finder</h1>
    </div>
  );
};

export default TripperFinderPage;
